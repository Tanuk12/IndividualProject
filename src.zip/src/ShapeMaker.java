import java.util.*;
public class ShapeMaker {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Length for Cube: ");
		int length = scan.nextInt();
		System.out.println("Width for Cube: ");
		int width = scan.nextInt();
		System.out.println("Height for Cube: ");
		int height = scan.nextInt();
	    Cuboid c1 = new Cuboid(length,width,height);
		System.out.println(c1.calcVol());
		System.out.println(c1.calcSurfaceArea());
		System.out.println("Length for Prism: ");
		int lengthP = scan.nextInt();
		System.out.println("Width for Prism: ");
		int widthP = scan.nextInt();
		System.out.println("Height for Prism: ");
		int heightP = scan.nextInt();
	    Prism p1 = new Prism(lengthP,widthP,heightP);
		System.out.println(p1.calcVol());
		System.out.println(p1.calcSurfaceArea());
		System.out.println("Radius for Sphere: ");
		int radius = scan.nextInt();
	    Sphere s1 = new Sphere(radius);
		System.out.println(s1.calcVol());
		System.out.println(s1.calcSurfaceArea());
		scan.close();

	}

}
